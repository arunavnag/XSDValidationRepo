'use strict'

module.exports = (component, moduleName) => {
    if (component[moduleName]) {
        return [component[moduleName]]
      } else {
        console.log(`no such component to export: ${moduleName}`)
      }
      return []
}
