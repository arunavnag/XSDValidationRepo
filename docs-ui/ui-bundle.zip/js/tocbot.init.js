var toc = document.getElementById( 'article-toc' );
if(toc)
{
  var levels = parseInt(toc.dataset.levels)
  if (levels > 0)
  {

    //generate h-level-list
    var headings = []
    for (var level = 2; level <= levels+1; level++) {
      headings.push("h" + level)
    }
    var headingSelector  = headings.join(',')

    tocbot.init( {
      tocSelector: '#article-toc',
      contentSelector: 'article',
      headingSelector: headingSelector,
      collapseDepth: 6,
      positionFixedSelector: '#article-toc',
      scrollSmooth: false
    } );


    var tocList = toc.getElementsByClassName( 'toc-list' );
    if ( tocList && tocList.length > 0 && tocList[0].childNodes.length > 0 ) {
      document.getElementById( 'article-aside-view' ).classList.remove( 'hidden' );
      document.getElementById( 'article-doc' ).classList.remove( 'hidden' );
    }

  }
}
