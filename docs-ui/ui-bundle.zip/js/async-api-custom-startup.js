function createDownloadButton(link) {

  var span =  document.createElement("span");
  span.textContent = "Download"

  var a = document.createElement("a");
  a.setAttribute("class","border border-solid border-grey-300 hover:bg-grey-200 text-gray-600 font-bold no-underline text-xs uppercase rounded px-3 py-1")
  a.setAttribute("href", link)
  a.setAttribute("download", "")
  a.setAttribute("target","_blank")
  a.setAttribute("rel","nofollow noopener noreferrer")
  a.appendChild(span)

  var li = document.createElement("li");
  li.setAttribute("class","inline-block mt-2 mr-2")
  li.appendChild(a)

  document.getElementById("introduction").children[1].appendChild(li)
};

// Function to create the download button
function observeRendering(adocfilename) {
  const targetNode = document.getElementById("asyncapi");

  const observer = new MutationObserver((mutationsList, observer) => {
    for (const mutation of mutationsList) {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        // Assuming the DOM is modified when rendering is finished
        createDownloadButton(adocfilename);
        observer.disconnect(); // Stop observing once the render is complete
        break;
      }
    }
  });

  // Start observing the target node for DOM changes
  observer.observe(targetNode, { childList: true });
}

function renderAsyncAPI(adocfilename) {
  observeRendering(adocfilename);

  AsyncApiStandalone.render({
    schema: {
      url: adocfilename,
      options: { method: "GET", mode: "cors" },
    },
    config: {
      show: {
        sidebar: true,
      }
    },
  }, document.getElementById("asyncapi"));
}
