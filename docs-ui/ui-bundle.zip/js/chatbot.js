function chatBotResponse(){
  console.log("MESSAGE JS");
  const apiKey = "8254279441584f30b2147d359a301f77";
  const resource = "bci-ai-sc.openai.azure.com";
  const deploymentModel = "Integration-guide";
  const apiVersion = "2023-12-01-preview"
  const apiUrl = `https://${resource}/openai/deployments/${deploymentModel}/chat/completions?api-version=${apiVersion}`;
  console.log(apiUrl);

  var inputMessage = (document.getElementById("userInputText")).value;
  console.log(inputMessage);
  var chat = document.getElementById("chat")
  chat.innerHTML += `
        <div class="message userMessage">
            <p>Prompt: ${inputMessage}</p>
        </div>`

  var bodyData = {
    "messages": [
        {
            "role": "user",
            "content": inputMessage
        }
    ]
  }
    const requestOptions = {
      method: 'POST', 
      headers: {
          'Content-Type': 'application/json', 
          'api-key':apiKey
      },
      body: JSON.stringify(bodyData)
    };
    fetch(apiUrl, requestOptions)
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        var resultData = data["choices"][0]["message"]["content"];
        console.log("resultData",resultData);
        chat.innerHTML += `
        <div class="message userMessage">
            <p>Result: ${resultData}</p>
        </div>`
        return data;
    })
    .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
        throw error;
    });
  return 0;
}