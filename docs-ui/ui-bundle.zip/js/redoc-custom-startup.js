function initCustomRedoc(path) {

    Redoc.init(path, {
      "scrollYOffset":".toolbar"
    }, document.getElementById('redoc-container'))
  }
